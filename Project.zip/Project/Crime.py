import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)
import seaborn as sns
import matplotlib.pyplot as plt 
import plotly.graph_objects as go
import plotly.express as px
import plotly.io as pio
import json
from urllib.request import urlopen

class Crime: 

    def __init__(self):
        try:
            # Read the file with pandas
            self.df = pd.read_excel("Bab 1 - Jenayah indeks 2020 v1.xlsx")
            self.df_crime = pd.DataFrame(pd.read_excel("Bab 1 - Jenayah indeks 2020 v1.xlsx", sheet_name="1.2 Crime Index Ratio"))
        except FileNotFoundError as e:
            print(f"Error: {e}")
            self.df = pd.DataFrame()
            self.df_crime = pd.DataFrame()
        except Exception as e:
            print(f"An error occurred: {e}")
            self.df = pd.DataFrame()
            self.df_crime = pd.DataFrame()
        
    def showTotalCrimeTable(self):
        # Show the total crime data with Pandas table
        if self.df.empty:
            print("DataFrame is empty. Cannot display the table.")
            return
        return self.df

    def ShowCrimeBarInYear(self, year):
        if self.df.empty:
            print("DataFrame is empty. Cannot display the chart.")
            return
        
        try:
            # Define the df
            df = self.df.copy()
            df.columns = df.columns.str.strip() # Delete the head of the table
            df17 = df.loc[(df.Year == year)] # We only want 2017 
            df17 = df17.reset_index(drop=True) # Resetting the Index 

            fig = px.bar(df17.iloc[1:], x='State', y='Total', hover_data=['Violent crime', 'Property crime'], width = 1000, color='Total',title=f"Table 1: Total Cases throughout each state in Malaysia in {year}")

            # Show the Chart
            fig.show()
            
        except Exception as e:
            print(f"An error occurred while creating the bar chart: {e}")

    def showCrimeRadioIndexTable(self):
        if self.df_crime.empty:
            print("DataFrame is empty. Cannot display the table.")
            return
        
        try:
            # Define the df_crime
            df_crime = self.df_crime.copy()

            df_crime.columns = df_crime.columns.str.strip() # Delete the Head of the table
            df_crime["Crime index ratio"]= df_crime["Crime index ratio"].round(decimals=1)
            return self.df_crime
        except Exception as e:
            print(f"An error occurred while processing the crime radio index table: {e}")

    def showCrimeRadioIndexBar(self):
        if self.df_crime.empty:
            print("DataFrame is empty. Cannot display the chart.")
            return
        
        try:
            # Define the df_crime
            df_crime = self.df_crime.copy()

            fig2 = px.bar(df_crime.iloc[3:] , x='State', y='Crime index ratio', hover_data=['Crime Index', 'Population',"Year"],width= 900, 
                color='Crime Index',title="Table 2 : Crime Index Ratio throughout 2017-2019")

            # Show the Chart
            fig2.show()
        except Exception as e:
            print(f"An error occurred while creating the bar chart: {e}")

    def showCrimeActivity(self, state, year):
        try:
            # Read the dataset based on the sheet name
            df_state = pd.DataFrame(pd.read_excel("Bab 1 - Jenayah indeks 2020 v1.xlsx", sheet_name=state))

            df_state.columns = df_state.columns.str.strip()
            df_state= df_state.replace("-",0)
            df_state_year = df_state[(df_state['Year'] == year) ].reset_index(drop=True)
            df_state_year = df_state_year.drop("Year", axis=1)

            return df_state_year
        except FileNotFoundError as e:
            print(f"Error: {e}")
            return pd.DataFrame()
        except Exception as e:
            print(f"An error occurred: {e}")
            return pd.DataFrame()

    def showCrimeActivityBar(self, state, year, area):
        try:
            # Read the dataset based on the sheet name
            df_state = pd.DataFrame(pd.read_excel("Bab 1 - Jenayah indeks 2020 v1.xlsx", sheet_name=state))

            df_state.columns = df_state.columns.str.strip()
            df_state = df_state.replace("-", 0)
            df_state_year = df_state[df_state['Year'] == year].reset_index(drop=True)
            df_state_year = df_state_year.drop("Year", axis=1)

            # Retrieve the area name using the provided index
            area_name = df_state_year.iloc[area, 0]  # Assuming the area name is in the first column

            df_state_year_wm = df_state_year.iloc[area]
            df_state_year_wm = pd.DataFrame(df_state_year_wm)
            df_state_year_wm2 = df_state_year_wm.iloc[2:].reset_index()

            df_state_year_wm2.rename(columns={5: "Total", "index": "Cases"}, inplace=True)
            fig = px.treemap(df_state_year_wm2, values=df_state_year_wm2.columns[1], path=["Cases"], width=600, height=700, title=f"Table 3 : The Amount of cases in {area_name}", color_discrete_sequence=px.colors.sequential.RdBu)

            # Show the Chart
            fig.show()
        except Exception as e:
            print(f"An error occurred while creating the treemap chart: {e}")

    def showCrimeRadioIndexYearTable(self, year):     
        try:
            with urlopen('https://raw.githubusercontent.com/nullifye/malaysia.geojson/master/malaysia.state.geojson') as response: 
                my_map = json.load(response)
                
            state_id_map={}

            for feature in my_map['features']:
                state_id_map[feature['properties']['state']] = feature['id']

            # Rename the all the names from the JSON file 
            rename =["Kedah","Kelantan","Perak","Pulau Pinang","Kuala Lumpur","Negeri Sembilan","Melaka",
                     "Perlis","Pahang","Terengganu","Putrajaya","Labuan","Selangor","Sabah","Johor","Sarawak"]

            state_id_map = dict(zip(rename , list(state_id_map.values())))  

            # Define the df_crime
            df_crime = self.df_crime.copy()

            # Taking the data based on the year 
            df_state_crime =df_crime.loc[(df_crime.Year == year)]  
            df_state_crime= df_state_crime.reset_index(drop=True) 
            df_state_crime= df_state_crime.loc[1:].reset_index(drop=True) 

            return df_state_crime  # Show the table
        except Exception as e:
            print(f"An error occurred while processing the crime radio index year table: {e}")
            return pd.DataFrame()

    def showCrimeRadioIndexYearMap(self, year):
        try:
            with urlopen('https://raw.githubusercontent.com/nullifye/malaysia.geojson/master/malaysia.state.geojson') as response: 
                my_map = json.load(response)
                
            state_id_map={}

            for feature in my_map['features']:
                state_id_map[feature['properties']['state']] = feature['id']

            # Rename the all the names from the JSON file 
            rename =["Kedah","Kelantan","Perak","Pulau Pinang","Kuala Lumpur","Negeri Sembilan","Melaka",
                     "Perlis","Pahang","Terengganu","Putrajaya","Labuan","Selangor","Sabah","Johor","Sarawak"]

            state_id_map = dict(zip(rename , list(state_id_map.values())))  

            # Define the df_crime
            df_crime = self.df_crime.copy()

            # Taking the data based on the year 
            df_state_crime =df_crime.loc[(df_crime.Year == year)]  
            df_state_crime= df_state_crime.reset_index(drop=True) 
            df_state_crime= df_state_crime.loc[1:].reset_index(drop=True) 

            df_state_crime["id"]=df_state_crime["State"].apply(lambda x : state_id_map.get(x, None))
            fig = px.choropleth(
                df_state_crime,
                locations="id",width=700,
                geojson=my_map,
                color="Crime index ratio",
                hover_name="State",
                hover_data=["Crime Index","Population"],
                title=f"Table 4 :Crime Index Ratio throughout Malaysia in {year}")
            fig.update_geos(fitbounds="locations", visible=False)
            fig.show()
        except Exception as e:
            print(f"An error occurred while creating the choropleth map: {e}")

    def compareCrimeAcrossStates(self, year1, year2):
        # 允许的年份列表
        valid_years = [2017, 2018, 2019]
        
        # 检查年份是否在允许的范围内
        if year1 not in valid_years or year2 not in valid_years:
            print("Error: Please select years from 2017, 2018, or 2019.")
            return
        
        if self.df.empty:
            print("DataFrame is empty. Cannot perform the comparison.")
            return
    
        try:
            # 选取年份对应的数据
            df_year1 = self.df[self.df.Year == year1].reset_index(drop=True)
            df_year2 = self.df[self.df.Year == year2].reset_index(drop=True)
    
            # 将两年的数据合并到一个DataFrame中
            df_comparison = pd.merge(
                df_year1[['State', 'Total']], 
                df_year2[['State', 'Total']], 
                on='State', 
                suffixes=(f'_{year1}', f'_{year2}')
            )
            
            # 计算犯罪变化率
            df_comparison['Change (%)'] = (
                (df_comparison[f'Total_{year2}'] - df_comparison[f'Total_{year1}']) / df_comparison[f'Total_{year1}']
            ) * 100
            
            # 打印列名以确认
            print("Columns after merge:", df_comparison.columns)
            print(f"Comparison of Total Crimes between {year1} and {year2}:")
            print(df_comparison)
            
            # 可视化比较结果（使用折线图）
            fig = px.line(
                df_comparison,
                x='State',
                y=[f'Total_{year1}', f'Total_{year2}'],
                title=f"Comparison of Total Crimes between {year1} and {year2}",
                labels={f'Total_{year1}': f'Total Crimes {year1}', f'Total_{year2}': f'Total Crimes {year2}'},
                markers=True
            )
            fig.update_layout(
                xaxis_title='State',
                yaxis_title='Total Crimes',
                legend_title='Year',
                title=f'Comparison of Total Crimes and Percentage Change ({year1} vs {year2})'
            )
            
            # 可视化百分比变化（调整x和y轴）
            fig2 = px.bar(
                df_comparison,
                x='Change (%)',
                y='State',
                title=f'Percentage Change in Total Crimes from {year1} to {year2}',
                labels={'Change (%)': 'Percentage Change', 'State': 'State'}
            )
            fig2.update_layout(
                xaxis_title='Percentage Change',
                yaxis_title='State',
                title=f'Percentage Change in Total Crimes ({year1} vs {year2})'
            )
            
            # 显示图表
            fig.show()
            fig2.show()
            
        except Exception as e:
            print(f"An error occurred while comparing crime data: {e}")
    
    def compareCrimeTypes(self, year1, year2=None, year3=None):
        valid_years = [2017, 2018, 2019]
    
        # 如果只提供了一个年份，则默认使用2018年作为另一个年份
        if year2 is None:
            year2 = 2018
        
        if year3 is not None and year3 not in valid_years:
            print(f"Error: Invalid year {year3} selected. Please choose from {valid_years}.")
            return
        
        # 检查年份是否有效
        if year1 not in valid_years or year2 not in valid_years:
            print(f"Error: Invalid years selected. Please choose from {valid_years}.")
            return
    
        if self.df.empty:
            print("DataFrame is empty. Cannot perform the comparison.")
            return
    
        try:
            # 选取指定年份的数据
            df_year1 = self.df.loc[self.df.Year == year1].reset_index(drop=True)
            df_year2 = self.df.loc[self.df.Year == year2].reset_index(drop=True)
    
            # 排除总和列，只保留具体的犯罪类型
            crime_types = df_year1.columns[3:]  # 假设前两列是'Year'和'State'，第三列是'Total'
            df_year1_sum = df_year1[crime_types].sum().reset_index()
            df_year2_sum = df_year2[crime_types].sum().reset_index()
    
            df_year1_sum.columns = ['Crime Type', f'Total Cases {year1}']
            df_year2_sum.columns = ['Crime Type', f'Total Cases {year2}']
    
            # 合并两年的数据
            df_comparison = pd.merge(df_year1_sum, df_year2_sum, on='Crime Type')
    
            if year3:
                df_year3 = self.df.loc[self.df.Year == year3].reset_index(drop=True)
                df_year3_sum = df_year3[crime_types].sum().reset_index()
                df_year3_sum.columns = ['Crime Type', f'Total Cases {year3}']
                df_comparison = pd.merge(df_comparison, df_year3_sum, on='Crime Type')
                
            # 计算犯罪变化率
            df_comparison['Change (%)'] = ((df_comparison[f'Total Cases {year2}'] - df_comparison[f'Total Cases {year1}']) / df_comparison[f'Total Cases {year1}']) * 100
    
            # 可视化不同年份的犯罪类型总和（调整x和y轴）
            y_columns = [f'Total Cases {year1}', f'Total Cases {year2}']
            if year3:
                y_columns.append(f'Total Cases {year3}')
                
            fig = px.bar(df_comparison, x=y_columns, y='Crime Type',
                         title=f"Total Cases of Different Crime Types in {year1}, {year2}" + (f", and {year3}" if year3 else ""),
                         labels={'value': 'Number of Cases'})
            fig.update_layout(
                xaxis_title='Number of Cases',
                yaxis_title='Crime Type',
                title=f'Total Cases of Different Crime Types ({year1}, {year2}' + (f', {year3}' if year3 else '') + ')'
            )
            fig.show()
    
            print(f"Summary of crime types in {year1}, {year2}" + (f", and {year3}" if year3 else "") + ":")
            print(df_comparison)
    
        except Exception as e:
            print(f"An error occurred while comparing crime types in {year1}, {year2}" + (f", and {year3}" if year3 else "") + f": {e}")
   